package com.example.wgu;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class courseList extends AppCompatActivity {

    private ListView courseList;
    private DataBase db;
    private Cursor data;
    private char index;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);

        courseList = (ListView) findViewById(R.id.courseList);
        db = new DataBase(this);

        Intent intent = getIntent();

        ArrayList<String> list = new ArrayList<>();

        if(intent.hasExtra("com.example.wgu.TERM_ID")){

            index = intent.getCharExtra("com.example.wgu.TERM_ID", ',');
            data = db.getCourse(Integer.parseInt(index + ""));

            while (data.moveToNext()){
                list.add(data.getString(0) + ". " + data.getString(2));
            }

            ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
            courseList.setAdapter(adapter);
            ((ArrayAdapter) adapter).notifyDataSetChanged();
        }

        courseList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String tag = (String) parent.getItemAtPosition(position).toString();

                Intent intent1 = new Intent(getApplicationContext(), singleCourse.class);
                intent1.putExtra("com.example.wgu.COURSE_ID", tag.charAt(0));
                startActivity(intent1);
            }
        });


    }

    @Override
    public void onRestart(){
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when user clicks on plus button while on course page
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(this, singleCourse.class);
        intent.putExtra("com.example.wgu.TERM_ID", index);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }


    private void msg(String st){

        Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
    }

}
