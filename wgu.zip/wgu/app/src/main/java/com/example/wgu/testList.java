package com.example.wgu;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class testList extends AppCompatActivity {

    DataBase db;
    private ListView testList;
    char index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_list);

        db = new DataBase(this);
        Intent intent = getIntent();
        testList = (ListView) findViewById(R.id.testList);

        ArrayList<String> list = new ArrayList<>();

        if(intent.hasExtra("com.example.wgu.COURSE_ID")){

            index = intent.getCharExtra("com.example.wgu.COURSE_ID", ',');

            Cursor data = db.getAllTest(Integer.parseInt(index + ""));

            while (data.moveToNext()){

                list.add( data.getString(0) + ". " +  data.getString(2));

            }

            ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
            testList.setAdapter(adapter);
            ((ArrayAdapter) adapter).notifyDataSetChanged();


        }

        testList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String tag = (String) parent.getItemAtPosition(position);

                Intent intent1 = new Intent(getApplicationContext(), singleTest.class);
                intent1.putExtra("com.example.wgu.TEST_ID", tag.charAt(0));
                startActivity(intent1);

            }
        });


    }

    @Override
    public void onRestart(){
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent = new Intent(this, singleTest.class);
        intent.putExtra("com.example.wgu.COURSE_ID", index);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }
}
