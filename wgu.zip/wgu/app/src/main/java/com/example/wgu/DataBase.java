package com.example.wgu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataBase extends SQLiteOpenHelper {

    public DataBase(Context context) {

        super(context, "tracker.db", null, 1);
    }

    @Override
    public SQLiteDatabase getWritableDatabase() {

        return super.getWritableDatabase();
    }



    @Override
    public void onCreate(SQLiteDatabase db) {


    }

    public void addTables(){

        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("create table if not exists term_table (id integer primary key autoincrement, title text unique, start date, endt date)");

        db.execSQL("create table if not exists course_table (id integer primary key autoincrement, termID integer, title text unique, start date, endt date, status text, mName text, mPhone text, mEmail text, note text, alarm integer, foreign key (termID) references term_table(id)   )");

        db.execSQL("create table if not exists test_table (id integer primary key autoincrement, courseID integer, name text unique, type text, start date, note text, alarm integer, foreign key (courseID) references course_table(id)   )");
    }

    //adds fake data for terms, courses and assessments
    public void fakeData(){

        addTerm("Term 1", "2019-02-01", "2019-03-01");
        addTerm("Term 2", "2019-04-01", "2019-05-01");
        addTerm("Term 3", "2019-06-01", "2019-07-01");

        addCourse(1, "Course 1", "2019-02-01", "2019-02-07", "Complete", "Black Smith", "222-333-4444", "black@email.com", "This is note for the Course 1", 1);
        addCourse(2, "Course 2", "2019-04-08", "2019-04-14", "In Progress", "Joe Smith", "333-444-5555", "joe@email.com", "This is note for the Course 2", 0);
        addCourse(3, "Course 3", "2019-06-01", "2019-06-08", "Not Started", "John Doe", "555-444-7777", "john@email.com", "This is note for the Course 3", 1);
        addCourse(1, "Course 4", "2019-02-15", "2019-02-23", "In Progress", "Jane Doe", "777-333-8888", "john@email.com", "This is note for the Course 4", 0);

        addTest(1, "Test 1", "OA", "2019-02-03", "This is a note for test 1", 0);
        addTest(2, "Test 2", "PA", "2019-04-10", "This is a note for test 2", 1);
        addTest(3, "Test 3", "OA", "2019-06-03", "This is a note for test 3", 0);
        addTest(4, "Test 4", "PA", "2019-02-18", "This is a note for test 4", 1);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    //add a new term to databse
    public boolean addTerm(String title, String start, String end){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("start", start);
        contentValues.put("endt", end);

        Log.d("DataBase ", " addTerm: Adding to term_table");
        long result = db.insert("term_table", null, contentValues);

        if(result == -1){
            return false;
        }else{
            return true;
        }

    }

    public boolean deleteTerm(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        int res =  db.delete("term_table", " id = ? ", new String[]{id});
        if(res > 0){
            return true;
        }else{
            return false;
        }
    }

    public boolean updateTerm(String title, String start, String end, String id){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("start", start);
        cv.put("endt", end);

        Log.d("DataBase ", " updateTerm: updating term_table");
        db.update("term_table", cv, " id = ?", new String[]{id});

        return true;

    }

    //returns the term_table
    public Cursor getTerm(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from term_table", null);
        return data;
    }

    //return single term by id
    public Cursor getTermById(int id){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from term_table where id = " + id, null);
        return data;
    }






    //return all courses by termID
    public Cursor getCourse(int id){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from course_table where termID = " + id, null);
        return data;

    }


    //return single course by id
    public Cursor getCourseById(int id){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from course_table where id = " + id , null);
        return data;
    }


    public Cursor getAllCourse(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from course_table", null);
        return data;
    }

    public Cursor getAllCourseByAlarm(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from course_table where alarm = 1", null);
        return data;
    }


    //insert course data into course_table
    public boolean addCourse(int termID, String title, String start, String endt, String status, String mName, String mPhone, String mEmail, String note, int alarm ){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cb = new ContentValues();
        cb.put("termID", termID);
        cb.put("title", title);
        cb.put("start", start);
        cb.put("endt", endt);
        cb.put("status", status);
        cb.put("mName", mName);
        cb.put("mPhone", mPhone);
        cb.put("mEmail", mEmail);
        cb.put("note", note);
        cb.put("alarm", alarm);

        Log.d("DataBase ", " addCourse: Adding to course_table");
        long result = db.insert("course_table", null, cb);

        if(result == -1){
            return false;
        }else{
            return true;
        }
    }

    //delete course by course id
    public boolean deleteCourse(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        int res =  db.delete("course_table", " id = ? ", new String[]{id});
        if(res > 0){
            return true;
        }else{
            return false;
        }
    }

    //update course
    public boolean updateCourse(String title, String start, String endt, String status, String mName, String mPhone, String mEmail, String note, int alarm, String id){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cb = new ContentValues();

        cb.put("title", title);
        cb.put("start", start);
        cb.put("endt", endt);
        cb.put("status", status);
        cb.put("mName", mName);
        cb.put("mPhone", mPhone);
        cb.put("mEmail", mEmail);
        cb.put("note", note);
        cb.put("alarm", alarm);

        Log.d("DataBase ", " updateCourse: Updating course_table");
        db.update("course_table", cb, " id = ?", new String[]{id});
        return true;

    }


    //test_table insert data
    public boolean addTest(int courseID, String name, String type, String start, String note, int alarm ){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("courseID", courseID);
        cv.put("name", name);
        cv.put("type", type);
        cv.put("start", start);
        cv.put("note", note);
        cv.put("alarm", alarm);

        Log.d("DataBase ", " addTest: Adding to test_table");
        long result = db.insert("test_table", null, cv);

        if(result == -1){
            return false;
        }else{
            return true;
        }

    }

    public boolean deleteTest(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        int res =  db.delete("test_table", " id = ? ", new String[]{id});
        if(res > 0){
            return true;
        }else{
            return false;
        }
    }

    //update test_table by test id
    public boolean updateTest(String name, String type, String start, String note, String id, int alarm ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("type", type);
        cv.put("start", start);
        cv.put("note", note);
        cv.put("alarm", alarm);
        Log.d("DataBase ", " updateTest: Updating test_table");
        db.update("test_table", cv, " id = ?", new String[]{id});
        return true;
    }

    //return the test by courseID
    public Cursor getTestById(int id){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from test_table where courseID = " + id, null);
        return data;
    }

    //return all tests by courseID
    public Cursor getAllTest(int id){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from test_table where courseID = "+ id, null);
        return data;
    }


    //returns the tests if the alert/alarm is true
    public Cursor getAllTestByAlarm(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from test_table where alarm = 1", null);
        return data;
    }

    //drop all tables
    public void dropTables(){

        this.getWritableDatabase().execSQL("drop table if exists test_table");
        this.getWritableDatabase().execSQL("drop table if exists course_table");
        this.getWritableDatabase().execSQL("drop table if exists term_table");
    }



}
