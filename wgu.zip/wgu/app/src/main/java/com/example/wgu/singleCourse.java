package com.example.wgu;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class singleCourse extends AppCompatActivity {

    private DatePickerDialog.OnDateSetListener dateSetListener;
    private DatePickerDialog.OnDateSetListener onDateSetListener;
    private DataBase db;
    private TextView courseName;
    private TextView startTV;
    private TextView endTV;
    private Spinner status;
    private TextView mName;
    private TextView mPhone;
    private TextView mEmail;
    private EditText note;
    private CheckBox alarm;
    char cIndex;
    char tIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_course);

        db = new DataBase(this);

        courseName = (TextView) findViewById(R.id.courseName);
        startTV = (TextView) findViewById(R.id.courseStart);
        endTV = (TextView) findViewById(R.id.courseEnd);
        status = (Spinner) findViewById(R.id.courseSpinner);
        mName = (TextView) findViewById(R.id.mentorName);
        mEmail = (TextView) findViewById(R.id.mentorEmail);
        mPhone = (TextView) findViewById(R.id.mentorPhone);
        note = (EditText) findViewById(R.id.noteEditText);
        alarm  = (CheckBox) findViewById(R.id.alarmCheckbox);

        Intent intent = getIntent();

        if(intent.hasExtra("com.example.wgu.COURSE_ID")){

            cIndex = intent.getCharExtra("com.example.wgu.COURSE_ID", ',');
            Cursor data = db.getCourseById(Integer.parseInt(cIndex + ""));

            while (data.moveToNext()){

                courseName.setText(data.getString(2));
                startTV.setText(data.getString(3));
                endTV.setText(data.getString(4));
                if(data.getString(5).equals("Complete")){
                    status.setSelection(0);
                }else if(data.getString(5).equals("In Progress")){
                    status.setSelection(1);
                }else{
                    status.setSelection(2);
                }
                mName.setText(data.getString(6));
                mPhone.setText(data.getString(7));
                mEmail.setText(data.getString(8));
                note.setText(data.getString(9));

                if(data.getInt(10) == 1){
                    alarm.setChecked(true);
                }

            }

        }

        startTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(singleCourse.this, android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth, dateSetListener, year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                month = month + 1;
                String date = String.format("%02d-%02d-%02d", year, month, dayOfMonth);

                startTV.setText(date);
            }
        };

        endTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(singleCourse.this, android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth, onDateSetListener, year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                month = month + 1;
                String date = String.format("%02d-%02d-%02d", year, month, dayOfMonth);

                endTV.setText(date);
            }
        };




    }

    public void saveUpCourse(View view){

        Intent intent = getIntent();
        String name = courseName.getText().toString();
        String start = startTV.getText().toString();
        String endt = endTV.getText().toString();
        String stat = status.getSelectedItem().toString();
        String mname = mName.getText().toString();
        String memail = mEmail.getText().toString();
        String mphone = mPhone.getText().toString();
        String not = note.getText().toString();
        boolean al = alarm.isChecked();
        int alert;

        if(al){
            alert = 1;
        }else{
            alert = 0;
        }


        if(intent.hasExtra("com.example.wgu.COURSE_ID")){


            boolean updated = db.updateCourse(name, start, endt, stat, mname, mphone, memail, not, alert, cIndex+"");
            if (updated){
                msg(" Course Successfully Updated!");
                finish();
            }else{
                msg(" No course was updated!");
            }

        }else{
            if(intent.hasExtra("com.example.wgu.TERM_ID")){
                tIndex = intent.getCharExtra("com.example.wgu.TERM_ID", ',');

                boolean saved = db.addCourse(Integer.parseInt(tIndex+""), name, start, endt, stat, mname, mphone, memail, not, alert);
                if (saved){
                    msg( "A new Course created!");
                    finish();
                }else{
                    msg( " No course was created!");
                }

            }
        }


    }//updateCourse

    //delete course by id
    public void deleteCourse(View view){
        Intent intent = getIntent();
        if(intent.hasExtra("com.example.wgu.COURSE_ID")){

            Cursor data = db.getAllTest(Integer.parseInt(cIndex+""));

            if (data.moveToNext()){
                AlertDialog.Builder alertDial = new AlertDialog.Builder(singleCourse.this);
                alertDial.setMessage("Can't be deleted! This course contains assessments.").setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                
                            }
                        });
                AlertDialog alert = alertDial.create();
                alert.setTitle("ALERT!");
                alert.show();
            }else{
                boolean del = db.deleteCourse(cIndex+"");

                if(del){
                    msg(" Successfully deleted!");
                    finish();
                }else{
                    msg(" Course delete didn't work!");
                }
            }

        }

    }




    public void showtestList(View view){

        Intent intent = new Intent(getApplicationContext(), testList.class);
        intent.putExtra("com.example.wgu.COURSE_ID", cIndex);
        startActivity(intent);
    }

    public void shareCourse(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        String body = note.getText().toString();
        intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
        intent.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(intent, "Share via"));
    }


    private void msg(String st){

        Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
    }


}


