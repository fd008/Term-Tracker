package com.example.wgu;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class singleTermActivity extends AppCompatActivity {

    private DatePickerDialog.OnDateSetListener dateSetListener;
    private DatePickerDialog.OnDateSetListener startdateSetListener;

    private TextView startDate;
    private TextView endDate;
    private EditText termName;

    private DataBase db;

    char index;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_term);

        db = new DataBase(this);

        startDate = (TextView) findViewById(R.id.courseStart);
        endDate = (TextView) findViewById(R.id.endDate);
        termName = (EditText) findViewById(R.id.termName);


        Intent intent = getIntent();

        if(intent.hasExtra("com.example.wgu.TERM_ID")){

            index = intent.getCharExtra("com.example.wgu.TERM_ID", ',');
            Log.d(" singleTermActivity ", " onCreate : fetching single term by id.");

            Cursor data = db.getTermById(Integer.parseInt(index + "") );

            while (data.moveToNext()){
                termName.setText(data.getString(1));
                startDate.setText(data.getString(2));
                endDate.setText(data.getString(3));
            }

        }



        startDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(singleTermActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth, startdateSetListener, year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        startdateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                month = month + 1;
                String date = String.format("%02d-%02d-%02d", year, month, dayOfMonth);

                startDate.setText(date);
            }
        };

        endDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(singleTermActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth, dateSetListener, year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                month = month + 1;
                String date = String.format("%02d-%02d-%02d", year, month, dayOfMonth);

                endDate.setText(date);
            }
        };


    }

    public void showCourses(View view){

        Intent intent = new Intent(this, courseList.class);
        intent.putExtra("com.example.wgu.TERM_ID", index);
        startActivity(intent);
    }

    public boolean isNum(String st) {
        return st.matches("[-+]?\\d*\\.?\\d+");
    }

    public void saveTerm(View view){

        String name = termName.getText().toString();
        String start = startDate.getText().toString();
        String endt = endDate.getText().toString();

        Intent intent = getIntent();

        if(intent.hasExtra("com.example.wgu.TERM_ID")){

            boolean insertTerm = db.updateTerm(name, start, endt, index+"");
            if(insertTerm){
                msg(" Successfully updated!");
                finish();
            }


        }else{

            boolean insertTerm = db.addTerm(name, start, endt);

            if(insertTerm){
                msg(" Successfully created!");
                finish();
            }

        }


    }

    //deletes a term when no course is added to it
    public void delTerm(View view){

        Intent intent = getIntent();

        if(intent.hasExtra("com.example.wgu.TERM_ID")){

            Cursor data = db.getCourse(Integer.parseInt(index+""));

            if(data.moveToNext()){

                AlertDialog.Builder alertDial = new AlertDialog.Builder(singleTermActivity.this);
                alertDial.setMessage("Can't be deleted! This term contains courses.").setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        });
                AlertDialog alert = alertDial.create();
                alert.setTitle("ALERT!");
                alert.show();

            }else{
                boolean del = db.deleteTerm(index+"");
                if(del){
                    msg(" Successfully deleted!");
                }else{
                    msg(" Delete didn't work!");
                }
                finish();
            }

        }
    }

    private void msg(String st){

        Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
    }


}
