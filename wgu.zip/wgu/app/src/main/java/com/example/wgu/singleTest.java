package com.example.wgu;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class singleTest extends AppCompatActivity {

    private DatePickerDialog.OnDateSetListener dateSetListener;
    private DataBase db;
    private Spinner testStatus;
    private EditText testName;
    private TextView testStart;
    private EditText testNote;
    private CheckBox alarm;
    char index;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_test);

        db = new DataBase(this);

        testName = (EditText) findViewById(R.id.testName);
        testStart = (TextView) findViewById(R.id.testStart);
        testNote = (EditText) findViewById(R.id.testNote);
        testStatus = (Spinner) findViewById(R.id.testType);
        alarm = (CheckBox) findViewById(R.id.testAlert);

        Intent intent = getIntent();

        if(intent.hasExtra("com.example.wgu.TEST_ID")){

            index = intent.getCharExtra("com.example.wgu.TEST_ID", ',');

            Cursor data = db.getTestById( Integer.parseInt(index + "") );

            while (data.moveToNext()){

                testName.setText(data.getString(2));
                if(data.getString(3).equals("OA")){
                    testStatus.setSelection(0);
                }else{
                    testStatus.setSelection(1);
                }
                testStart.setText(data.getString(4));
                testNote.setText(data.getString(5));

                if(data.getInt(6) == 1){
                    alarm.setChecked(true);
                }

            }

        }

        testStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(singleTest.this, android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth, dateSetListener, year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                month = month + 1;
                String date = String.format("%02d-%02d-%02d", year, month, dayOfMonth);

                testStart.setText(date);
            }
        };





    }

    //this method handles both saving new and update test_table
    public void saveTest(View view){

        Intent intent = getIntent();
        String name = testName.getText().toString();
        String type = testStatus.getSelectedItem().toString();
        String start = testStart.getText().toString();
        String note = testNote.getText().toString();
        boolean showAlarm = alarm.isChecked();
        char cID;
        int alertIndex;
        if(showAlarm){
            alertIndex = 1;
        }else {
            alertIndex = 0;
        }

        //if there is test id, then it must be update
        if(intent.hasExtra("com.example.wgu.TEST_ID")){

            boolean updated = db.updateTest(name, type, start, note, index+"", alertIndex);
            if(updated){
                msg(" Successfully updated test_table!");
                finish();
            }

        }else{
            //if there is not test id, then it must have course id to add
            cID = intent.getCharExtra("com.example.wgu.COURSE_ID", ',');

            boolean saved = db.addTest(Integer.parseInt(cID+""), name, type, start, note, alertIndex);
            if(saved){
                msg(" Successfully created a new test!");
                finish();
            }

        }

    }

    public void delTest(View view){
        Intent intent = getIntent();
        if(intent.hasExtra("com.example.wgu.TEST_ID")){
            boolean del = db.deleteTest(index+"");
            if(del){
                msg(" Successfully deleted!");
                finish();
            }else{
                msg(" Delete test didn't work!");

            }
        }
    }

    public void shareTest(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        String body = testNote.getText().toString();
        intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
        intent.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(intent, "Share via"));
    }



    private void msg(String st){

        Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
    }


}
