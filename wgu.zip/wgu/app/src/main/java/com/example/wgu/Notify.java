package com.example.wgu;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class Notify extends Application {

    public static final String ch1_ID = "wgu1";
    public static final String ch2_ID = "wgu2";


    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannels();
    }


    private void createNotificationChannels(){

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            NotificationChannel ch1 = new NotificationChannel(ch1_ID, "Channel 1", NotificationManager.IMPORTANCE_HIGH);



            ch1.setDescription("This is channel 1");



            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(ch1);

        }

    }

}
