package com.example.wgu;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    DataBase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        db = new DataBase(this);
        db.addTables();
        db.fakeData();

        startService();

    }



    public void showTerm(View view){

        Intent intent = new Intent(this, termList.class);
        startActivity(intent);


    }

    public void startService(){

        String out = "";

        //gets all the courses that checked the alert/notification checkbox
        Cursor data = db.getAllCourseByAlarm();

        //gets the all the assessments where alert/notification is set to true
        Cursor data1  = db.getAllTestByAlarm();

        while ( data.moveToNext() && data1.moveToNext() ) {
            out = "Course  #" + data.getString(0) + " Starts: " + data.getString(3) + " Test #" + data1.getString(0) + " Starts: " + data1.getString(4);
        }


        Intent intent = new Intent(this, Worker.class);
        intent.putExtra("wguTracker", out);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        }

    }

    public void stopService(View v){
        Intent intent = new Intent(this, Worker.class);
        stopService(intent);
    }




}
